
document.addEventListener("DOMContentLoaded", () => {
    // ==============================
    // MENU MOBILE
    // ==============================

    const nav = document.querySelector(".main-nav");
    const navToggle = document.querySelector(".nav-toggle");

    if (navToggle && nav) {
        navToggle.addEventListener("click", () => {
            const open = nav.classList.toggle("open");
            navToggle.setAttribute("aria-expanded", String(open));
        });
    }

    // ==============================
    // ANNÉE DU FOOTER
    // ==============================

    const year = document.querySelector("#year");

    if (year) {
        year.textContent = new Date().getFullYear();
    }

    // ==============================
    // MENU CLUB
    // ==============================

    const clubButton = document.querySelector(".nav-club-button");
    const clubMenu = document.querySelector(".nav-club-menu");

    // ==============================
    // MENU ÉQUIPES
    // ==============================

    const teamButton = document.querySelector(".nav-team-button");
    const teamMenu = document.querySelector(".nav-team-menu");
    const panels = document.querySelectorAll(".nav-team-panel");

    function showFirstPanel() {
        panels.forEach(panel => {
            panel.hidden = !panel.classList.contains("nav-team-level-1");
        });
    }

    function showPanel(name) {
        panels.forEach(panel => {
            panel.hidden = panel.dataset.panel !== name;
        });
    }

    function closeClubMenu() {
        if (!clubButton || !clubMenu) return;

        clubMenu.hidden = true;
        clubButton.setAttribute("aria-expanded", "false");
    }

    function closeTeamMenu() {
        if (!teamButton || !teamMenu) return;

        teamMenu.hidden = true;
        teamButton.setAttribute("aria-expanded", "false");
        showFirstPanel();
    }

    // Initialisation des menus
    if (clubMenu) {
        clubMenu.hidden = true;
    }

    if (teamMenu) {
        showFirstPanel();
        teamMenu.hidden = true;
    }

    // Bouton LE CLUB
    if (clubButton && clubMenu) {
        clubButton.addEventListener("click", event => {
            event.stopPropagation();

            const isOpen =
                clubButton.getAttribute("aria-expanded") === "true";

            closeTeamMenu();

            clubMenu.hidden = isOpen;
            clubButton.setAttribute("aria-expanded", String(!isOpen));
        });

        clubMenu.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", closeClubMenu);
        });
    }

    // Bouton ÉQUIPES
    if (teamButton && teamMenu) {
        teamButton.addEventListener("click", event => {
            event.stopPropagation();

            const isOpen =
                teamButton.getAttribute("aria-expanded") === "true";

            closeClubMenu();

            teamMenu.hidden = isOpen;
            teamButton.setAttribute("aria-expanded", String(!isOpen));

            if (!isOpen) {
                showFirstPanel();
            }
        });

        teamMenu.querySelectorAll(".nav-team-next").forEach(button => {
            button.addEventListener("click", event => {
                event.stopPropagation();
                showPanel(button.dataset.next);
            });
        });

        teamMenu.querySelectorAll(".nav-team-back").forEach(button => {
            button.addEventListener("click", event => {
                event.stopPropagation();

                const back = button.dataset.back || "level-1";

                if (back === "level-1") {
                    showFirstPanel();
                } else {
                    showPanel(back);
                }
            });
        });

        teamMenu.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", closeTeamMenu);
        });
    }

    // Fermer les menus en cliquant ailleurs
    document.addEventListener("click", event => {
        if (!event.target.closest(".nav-club-dropdown")) {
            closeClubMenu();
        }

        if (!event.target.closest(".nav-team-dropdown")) {
            closeTeamMenu();
        }
    });

    // Fermer avec Échap
    document.addEventListener("keydown", event => {
        if (event.key === "Escape") {
            closeClubMenu();
            closeTeamMenu();
        }
    });

    // ==============================
    // CARTES CLIQUABLES
    // ==============================

    document.querySelectorAll(".info-card[data-page]").forEach(card => {
        card.addEventListener("click", () => {
            window.location.href = card.dataset.page;
        });
    });
});
